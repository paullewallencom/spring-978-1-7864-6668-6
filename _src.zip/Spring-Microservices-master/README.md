## $5 Tech Unlocked 2021!
[Buy and download this Book for only $5 on PacktPub.com](https://www.packtpub.com/product/spring-microservices/9781786466686)
-----
*If you have read this book, please leave a review on [Amazon.com](https://www.amazon.com/gp/product/1786466686).     Potential readers can then use your unbiased opinion to help them make purchase decisions. Thank you. The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Spring Microservices
Code repository for [Spring Microservices](https://www.packtpub.com/application-development/spring-microservices?utm_source=github&utm_medium=repository&utm_campaign=9781786466686), published by Packt Publishing

There are no code files for chapters 1, 3, and 10. All hardware requirements are listed in the file named "Hardware and Software requirements". Any other requirements are mentioned in the book wherever necessary.

# Related books
* [Spring Security 3.x Cookbook](https://www.packtpub.com/application-development/spring-security-3x-cookbook?utm_source=github&utm_medium=related&utm_campaign=9781782167525)
* [Learning Spring Boot](https://www.packtpub.com/application-development/learning-spring-boot?utm_source=github&utm_medium=related&utm_campaign=9781784393021)
* [Mastering Microservices with Java](https://www.packtpub.com/application-development/mastering-microservices-java?utm_source=github&utm_medium=related&utm_campaign=9781785285172) - to be published in June 2016


